package kolekcije;

public class Letovi implements Comparable<Letovi>{
	
	private String destinacija;
	private int cena;
	private int vremePolaska;
	private int vremeDolaska;
	
	public Letovi(){
	
	}
	
	public Letovi(String destinacija,int cena, int vremePolaska,int vremeDolaska){
		
		this.destinacija=destinacija;
		
		this.vremePolaska=vremePolaska;
		this.vremeDolaska=vremeDolaska;
		
		this.cena=cena;
	}
	
	public String getDestinacija(){
		return destinacija;
	}

	public void setDestinacija(String destinacija){
		this.destinacija=destinacija;
	}
	
	
	
	public int getVremePolaska(){
		return vremePolaska;
	}
	
	public void setVremePolaska(int vremePolaska){
		this.vremePolaska=vremePolaska;
	}
	
	public int getVremeDolaska(){
		return vremeDolaska;
	}
	
	public void setVremeDolaska(int vremeDolaska){
		this.vremeDolaska=vremeDolaska;
	}
	
	public int getCena(){
		return cena;
	}
	
	public void setCena(int cena){
		this.cena=cena;
	}
	
	
	//kopirani konsrtruktor
	public Letovi(Letovi l){
		this.destinacija=l.getDestinacija();
		
		this.vremePolaska=l.getVremePolaska();
		this.vremeDolaska=l.getVremeDolaska();
		this.cena=l.getCena();
		
		
	}
	
	public String toString(){
		return destinacija + " | " + cena  + ":00h" + "-"+vremeDolaska + ":00h"+ " - "  + vremePolaska + "din";
	}
	
/*ublic int hashCode() {
        return cena;
    }*/
	
	public int compareTo(Letovi l){
		return cena-l.cena;
	}


	
	
	
	
	

}
