package kolekcije;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

public class Main {
	
	public Main(){
		List<Letovi> listaLetova=new ArrayList<Letovi>();
		
		listaLetova.add(new Letovi("Nis-Zurich",9,12000,13));
		listaLetova.add(new Letovi("Nis-Berlin",10, 10000,12));
		listaLetova.add(new Letovi("Nis-Eindhoven",11, 1500,14));
		listaLetova.add(new Letovi("Nis-Dortmund",8, 8000,11));
		
		/*for (int i=0;i<10;i++){
			listaLetova.add(new Letovi(Pomocna.getName(6),Pomocna.getRandom(15000)));
		}*/
		
		System.out.println("Broj letova: " + listaLetova.size());
		
		System.out.println(listaLetova);
		/*printLlist(listaLetova);
		
		listaLetova.add(new Letovi("Zurich", 12000));
		listaLetova.add(new Letovi("Berlin", 10000));
		listaLetova.add(new Letovi("Eindhoven", 1500));
		listaLetova.add(new Letovi("Dortmund", 8000));
		
/*		Set<Letovi> listUnique = new TreeSet<Letovi>(listaLetova);
        printList(listUnique);
    }*/

		
	}

	

/*	private void printList(Collection<Letovi> coll) {
		
		for(Letovi l : coll ){
			System.out.println(l);
			
		}*/
	
		/*Pomocna.getName(6),*/
		
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		new Main();
		
		
		
	}

}
