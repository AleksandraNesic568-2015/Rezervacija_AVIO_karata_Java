package kolekcije;

import java.util.Random;

public class Pomocna {

	static private Random r = new Random();
	
	static public int getRandom(int x){
        return r.nextInt(x);
    }
	
	public static String getName(int brSlova){
		
		Random r = new Random();
		String rec="";
		
		
	    char rec = (char) ('A' + r.nextInt(10));
        for(int i=0; i<brSlova-1; i++)
            rec += (char) ('a' + r.nextInt(10));
        return rec;
	}
}

	
	
	
	
	

